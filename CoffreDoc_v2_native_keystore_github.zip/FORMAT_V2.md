# Format de conteneur CoffreDoc V2

Tous les entiers sont stockés en ordre réseau, big-endian.

## En-tête global — 10 octets

| Taille | Contenu |
|---:|---|
| 4 | magie ASCII `CDOC` |
| 1 | version : `2` |
| 1 | algorithme : `1` = AES-256-GCM par blocs |
| 4 | taille de bloc nominale en clair |

L'en-tête global complet est ajouté comme AAD à chaque opération AES-GCM.

## Enregistrement de bloc — 21 octets, puis données chiffrées

| Taille | Contenu |
|---:|---|
| 1 | type : `0` données, `1` fin |
| 4 | index séquentiel du bloc |
| 4 | longueur du texte clair |
| 12 | IV GCM aléatoire |
| N + 16 | texte chiffré et tag GCM de 128 bits |

L'en-tête de l'enregistrement complet est ajouté comme AAD avec l'en-tête global.

Un enregistrement final de type `1`, de longueur claire nulle, termine toujours
le document. Son tag authentifie la fin du flux et permet de détecter une
troncature située exactement entre deux blocs valides.
