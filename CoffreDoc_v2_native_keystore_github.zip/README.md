# CoffreDoc V2

Petit outil Android local pour chiffrer et déchiffrer des documents sur le téléphone.

## Fonctions

- sélection des fichiers avec le sélecteur de documents Android ;
- chiffrement AES-256-GCM natif, sans `androidx.security:security-crypto` ;
- clé AES non exportable créée dans Android Keystore ;
- traitement par blocs authentifiés de 1 Mio, adapté aux gros documents ;
- vérification complète du fichier chiffré avant la création du document restauré ;
- aucune permission Internet ;
- aucune permission globale de stockage ;
- aucun document en clair conservé dans le cache privé de l'application.

Le document original reste inchangé. CoffreDoc crée une copie `.ncrypt` et laisse
l'utilisateur décider ensuite s'il souhaite supprimer l'original.

## Cryptographie

La V2 utilise directement les API Android et Java :

- `AndroidKeyStore` ;
- `KeyGenParameterSpec` ;
- clé AES de 256 bits ;
- `AES/GCM/NoPadding` ;
- IV aléatoire de 96 bits pour chaque bloc ;
- tag GCM de 128 bits pour chaque bloc ;
- en-têtes et ordre des blocs inclus dans les données authentifiées ;
- bloc final vide et authentifié pour détecter les fichiers tronqués.

Le moteur est réparti entre :

- `AndroidKeystoreKeyProvider.kt` : création et récupération de la clé non exportable ;
- `ChunkedAesGcm.kt` : format `.ncrypt` V2 et traitement cryptographique ;
- `CryptoManager.kt` : accès aux documents Android et gestion des erreurs.

La dépendance dépréciée `androidx.security:security-crypto` a été entièrement retirée.

## Compatibilité avec CoffreDoc V1

Le format V2 n'est pas compatible avec les fichiers produits par la première
version fondée sur `EncryptedFile`. L'application les identifie et affiche un
message explicite au lieu de les considérer comme des fichiers corrompus.

La clé V2 utilise également un nouvel alias Keystore :

```text
coffredoc_aes256_gcm_v2
```

## Limite essentielle

La clé n'est pas un mot de passe exportable. Elle appartient à cette installation
de CoffreDoc sur ce téléphone.

Les fichiers ne pourront plus être déchiffrés après :

- désinstallation de l'application ;
- effacement de ses données ;
- changement de téléphone ;
- perte ou réinitialisation du Keystore Android.

Les sauvegardes et transferts automatiques des données privées de l'application
sont désactivés pour éviter de restaurer des données sans leur clé Keystore.

## Compilation dans Android Studio

Prérequis :

- JDK 17 ;
- Android SDK 35 ;
- Android Studio récent.

Ouvrir le dossier du projet puis utiliser :

```text
Build > Build APK(s)
```

APK debug :

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Compilation automatique avec GitHub Actions

Le workflow est inclus dans :

```text
.github/workflows/build-apk.yml
```

Procédure :

1. créer un dépôt GitHub vide ;
2. placer directement à la racine du dépôt les dossiers `app`, `gradle`, `.github`
   et les fichiers `gradlew`, `settings.gradle.kts`, etc. ;
3. pousser le projet sur la branche `main` ;
4. ouvrir l'onglet **Actions** du dépôt ;
5. ouvrir **Build APK** ;
6. télécharger l'artefact **CoffreDoc-v2-debug-apk**.

Le workflow exécute :

```bash
./gradlew --no-daemon clean testDebugUnitTest assembleDebug
```

L'artefact contient :

- `CoffreDoc-v2-debug.apk` ;
- `CoffreDoc-v2-debug.apk.sha256`.

Le workflow peut également être lancé manuellement avec **Run workflow**.

## Tests inclus

Les tests JVM vérifient notamment :

- un aller-retour sur un document de plusieurs blocs ;
- un document vide ;
- le rejet d'un fichier modifié ;
- le rejet d'un fichier tronqué ;
- la détection explicite du format V1.

## Test conseillé sur téléphone

1. créer un petit fichier texte ;
2. le chiffrer en `test.txt.ncrypt` ;
3. le déchiffrer vers un nouveau fichier ;
4. comparer le contenu ;
5. modifier un octet du `.ncrypt` et vérifier que CoffreDoc refuse sa restauration ;
6. conserver les originaux jusqu'à validation complète de l'application sur le téléphone.
