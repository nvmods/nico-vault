package fr.nicovape.coffredoc.crypto

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.security.SecureRandom
import javax.crypto.AEADBadTagException
import javax.crypto.KeyGenerator

class ChunkedAesGcmTest {

    private val codec = ChunkedAesGcm()
    private val key = KeyGenerator.getInstance("AES").apply { init(256) }.generateKey()

    @Test
    fun roundTripMultiChunkDocument() {
        val clear = ByteArray(2_500_123).also { SecureRandom().nextBytes(it) }
        val encrypted = ByteArrayOutputStream()

        val encryptedCount = codec.encrypt(ByteArrayInputStream(clear), encrypted, key)
        val restored = ByteArrayOutputStream()
        val decryptedCount = codec.decrypt(
            ByteArrayInputStream(encrypted.toByteArray()),
            restored,
            key
        )

        assertEquals(clear.size.toLong(), encryptedCount)
        assertEquals(clear.size.toLong(), decryptedCount)
        assertArrayEquals(clear, restored.toByteArray())
    }

    @Test
    fun roundTripEmptyDocument() {
        val encrypted = ByteArrayOutputStream()
        codec.encrypt(ByteArrayInputStream(ByteArray(0)), encrypted, key)

        val restored = ByteArrayOutputStream()
        val count = codec.decrypt(ByteArrayInputStream(encrypted.toByteArray()), restored, key)

        assertEquals(0L, count)
        assertArrayEquals(ByteArray(0), restored.toByteArray())
    }

    @Test
    fun alteredCiphertextIsRejected() {
        val clear = "document confidentiel".encodeToByteArray()
        val encrypted = ByteArrayOutputStream()
        codec.encrypt(ByteArrayInputStream(clear), encrypted, key)

        val altered = encrypted.toByteArray()
        altered[altered.lastIndex - 2] = (altered[altered.lastIndex - 2].toInt() xor 0x01).toByte()

        assertThrows(AEADBadTagException::class.java) {
            codec.decrypt(ByteArrayInputStream(altered), ByteArrayOutputStream(), key)
        }
    }

    @Test
    fun truncatedContainerIsRejected() {
        val encrypted = ByteArrayOutputStream()
        codec.encrypt(
            ByteArrayInputStream("test".encodeToByteArray()),
            encrypted,
            key
        )
        val truncated = encrypted.toByteArray().copyOf(encrypted.size() - 5)

        assertThrows(CoffreDocFormatException::class.java) {
            codec.decrypt(ByteArrayInputStream(truncated), ByteArrayOutputStream(), key)
        }
    }

    @Test
    fun legacyV1HeaderIsReportedExplicitly() {
        val legacyHeader = byteArrayOf(0x43, 0x44, 0x4F, 0x43, 0x01, 0x00, 0, 0, 0, 0)

        assertThrows(CoffreDocLegacyFormatException::class.java) {
            codec.decrypt(ByteArrayInputStream(legacyHeader), ByteArrayOutputStream(), key)
        }
    }
}
