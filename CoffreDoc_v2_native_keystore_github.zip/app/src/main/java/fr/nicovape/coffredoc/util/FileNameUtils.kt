package fr.nicovape.coffredoc.util

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap

object FileNameUtils {

    fun displayName(context: Context, uri: Uri): String {
        val queriedName = runCatching {
            context.contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0 && cursor.moveToFirst()) cursor.getString(index) else null
            }
        }.getOrNull()

        return sanitize(queriedName ?: uri.lastPathSegment ?: "document")
    }

    fun encryptedName(originalName: String): String {
        val cleanName = sanitize(originalName)
        return if (cleanName.endsWith(ENCRYPTED_EXTENSION, ignoreCase = true)) {
            cleanName
        } else {
            "$cleanName$ENCRYPTED_EXTENSION"
        }
    }

    fun decryptedName(encryptedName: String): String {
        val cleanName = sanitize(encryptedName)
        val withoutExtension = if (cleanName.endsWith(ENCRYPTED_EXTENSION, ignoreCase = true)) {
            cleanName.dropLast(ENCRYPTED_EXTENSION.length)
        } else {
            "dechiffre_$cleanName"
        }

        return withoutExtension.ifBlank { "document_dechiffre" }
    }

    fun guessedMimeType(fileName: String): String {
        val extension = fileName.substringAfterLast('.', missingDelimiterValue = "")
            .lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
            ?: "application/octet-stream"
    }

    private fun sanitize(name: String): String = name
        .replace('/', '_')
        .replace('\\', '_')
        .replace('\u0000', '_')
        .trim()
        .take(MAX_NAME_LENGTH)
        .ifBlank { "document" }

    private const val ENCRYPTED_EXTENSION = ".ncrypt"
    private const val MAX_NAME_LENGTH = 180
}
