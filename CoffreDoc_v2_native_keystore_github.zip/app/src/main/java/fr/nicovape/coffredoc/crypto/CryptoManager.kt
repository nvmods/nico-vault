package fr.nicovape.coffredoc.crypto

import android.content.Context
import android.net.Uri
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.IOException

/**
 * Pont entre le Storage Access Framework Android et le moteur AES-GCM natif.
 *
 * Aucune API androidx.security.crypto n'est utilisée. La clé AES-256 est fournie
 * par Android Keystore et n'est jamais exportée dans les fichiers de l'application.
 */
class CryptoManager(context: Context) {

    private val appContext = context.applicationContext
    private val operationLock = Any()
    private val keyProvider = AndroidKeystoreKeyProvider()
    private val codec = ChunkedAesGcm()

    /** Chiffre le document sélectionné vers le fichier .ncrypt choisi. */
    fun encrypt(sourceUri: Uri, destinationUri: Uri): Long = synchronized(operationLock) {
        ensureDifferentDocuments(sourceUri, destinationUri)
        try {
            val key = keyProvider.getOrCreateKey()
            val resolver = appContext.contentResolver

            resolver.openInputStream(sourceUri)
                ?.let(::BufferedInputStream)
                ?.use { clearInput ->
                    resolver.openOutputStream(destinationUri, "w")
                        ?.let(::BufferedOutputStream)
                        ?.use { encryptedOutput ->
                            codec.encrypt(clearInput, encryptedOutput, key)
                        }
                        ?: throw IOException("Impossible de créer le document chiffré.")
                }
                ?: throw IOException("Impossible d'ouvrir le document source.")
        } catch (error: Throwable) {
            removeOrTruncateDestination(destinationUri)
            throw error
        }
    }

    /**
     * Déchiffre un conteneur CoffreDoc V2.
     *
     * Le fichier chiffré est d'abord copié dans le cache privé, puis authentifié en
     * totalité. Le document de destination n'est créé qu'après cette vérification.
     * Le cache ne contient donc que du texte chiffré, jamais le document en clair.
     */
    fun decrypt(sourceUri: Uri, destinationUri: Uri): Long = synchronized(operationLock) {
        ensureDifferentDocuments(sourceUri, destinationUri)
        val localEncryptedCopy = createEncryptedTemporaryFile()

        try {
            copyEncryptedSourceToTemporaryFile(sourceUri, localEncryptedCopy)
            val key = keyProvider.getOrCreateKey()

            // Première passe : vérification intégrale sans produire de texte clair.
            localEncryptedCopy.inputStream()
                .let(::BufferedInputStream)
                .use { encryptedInput ->
                    codec.decrypt(encryptedInput, output = null, key = key)
                }

            // Deuxième passe sur la même copie immuable : restitution vers le SAF.
            val resolver = appContext.contentResolver
            resolver.openOutputStream(destinationUri, "w")
                ?.let(::BufferedOutputStream)
                ?.use { clearOutput ->
                    localEncryptedCopy.inputStream()
                        .let(::BufferedInputStream)
                        .use { encryptedInput ->
                            codec.decrypt(encryptedInput, clearOutput, key)
                        }
                }
                ?: throw IOException("Impossible de créer le document déchiffré.")
        } catch (error: Throwable) {
            removeOrTruncateDestination(destinationUri)
            throw error
        } finally {
            localEncryptedCopy.delete()
        }
    }

    /** Supprime uniquement d'éventuelles copies temporaires chiffrées de CoffreDoc. */
    fun cleanupTemporaryFiles() = synchronized(operationLock) {
        appContext.cacheDir.listFiles()
            ?.filter { it.name.startsWith(TEMP_FILE_PREFIX) }
            ?.forEach { it.delete() }
    }


    private fun ensureDifferentDocuments(sourceUri: Uri, destinationUri: Uri) {
        if (sourceUri == destinationUri) {
            throw IOException(
                "Le document source et le document de destination doivent être différents."
            )
        }
    }

    private fun copyEncryptedSourceToTemporaryFile(sourceUri: Uri, destination: File) {
        appContext.contentResolver.openInputStream(sourceUri)
            ?.let(::BufferedInputStream)
            ?.use { sourceInput ->
                destination.outputStream()
                    .let(::BufferedOutputStream)
                    .use { temporaryOutput ->
                        sourceInput.copyTo(temporaryOutput, BUFFER_SIZE)
                    }
            }
            ?: throw IOException("Impossible d'ouvrir le fichier chiffré.")

        if (destination.length() == 0L) {
            throw CoffreDocFormatException("Le fichier chiffré est vide.")
        }
    }

    private fun createEncryptedTemporaryFile(): File = File.createTempFile(
        TEMP_FILE_PREFIX,
        TEMP_FILE_SUFFIX,
        appContext.cacheDir
    )

    private fun removeOrTruncateDestination(uri: Uri) {
        val resolver = appContext.contentResolver
        val deleted = runCatching { resolver.delete(uri, null, null) > 0 }.getOrDefault(false)

        if (!deleted) {
            // Certains fournisseurs SAF refusent delete() : on tente au minimum de
            // supprimer tout contenu partiellement écrit.
            runCatching {
                resolver.openOutputStream(uri, "rwt")?.use { it.flush() }
            }.recoverCatching {
                resolver.openOutputStream(uri, "w")?.use { it.flush() }
            }
        }
    }

    private companion object {
        const val TEMP_FILE_PREFIX = "coffredoc_v2_"
        const val TEMP_FILE_SUFFIX = ".ncrypt.tmp"
        const val BUFFER_SIZE = 64 * 1024
    }
}
