package fr.nicovape.coffredoc

import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import fr.nicovape.coffredoc.crypto.CoffreDocFormatException
import fr.nicovape.coffredoc.crypto.CoffreDocLegacyFormatException
import fr.nicovape.coffredoc.crypto.CryptoManager
import fr.nicovape.coffredoc.util.FileNameUtils
import java.io.IOException
import java.security.GeneralSecurityException
import java.security.KeyStoreException
import javax.crypto.AEADBadTagException
import java.text.DecimalFormat
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var buttonEncrypt: Button
    private lateinit var buttonDecrypt: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var textStatus: TextView

    private val worker = Executors.newSingleThreadExecutor()
    private val cryptoManager by lazy { CryptoManager(applicationContext) }

    private var pendingEncryptSource: Uri? = null
    private var pendingDecryptSource: Uri? = null

    private val chooseFileToEncrypt = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@registerForActivityResult

        pendingEncryptSource = uri
        val sourceName = FileNameUtils.displayName(this, uri)
        createEncryptedFile.launch(FileNameUtils.encryptedName(sourceName))
    }

    private val createEncryptedFile = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { destinationUri ->
        val sourceUri = pendingEncryptSource
        pendingEncryptSource = null

        if (sourceUri != null && destinationUri != null) {
            runCryptoOperation(
                runningMessage = "Chiffrement en cours…",
                successPrefix = "Document chiffré",
                operation = { cryptoManager.encrypt(sourceUri, destinationUri) }
            )
        }
    }

    private val chooseFileToDecrypt = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@registerForActivityResult

        pendingDecryptSource = uri
        val encryptedName = FileNameUtils.displayName(this, uri)
        val suggestedName = FileNameUtils.decryptedName(encryptedName)

        // Le contrat CreateDocument doit avoir un type fixé lors de son enregistrement.
        // L'extension originale est néanmoins conservée dans le nom proposé.
        createDecryptedFile.launch(suggestedName)
    }

    private val createDecryptedFile = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { destinationUri ->
        val sourceUri = pendingDecryptSource
        pendingDecryptSource = null

        if (sourceUri != null && destinationUri != null) {
            runCryptoOperation(
                runningMessage = "Déchiffrement en cours…",
                successPrefix = "Document déchiffré",
                operation = { cryptoManager.decrypt(sourceUri, destinationUri) }
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        buttonEncrypt = findViewById(R.id.buttonEncrypt)
        buttonDecrypt = findViewById(R.id.buttonDecrypt)
        progressBar = findViewById(R.id.progressBar)
        textStatus = findViewById(R.id.textStatus)

        cryptoManager.cleanupTemporaryFiles()

        buttonEncrypt.setOnClickListener {
            chooseFileToEncrypt.launch(arrayOf("*/*"))
        }

        buttonDecrypt.setOnClickListener {
            chooseFileToDecrypt.launch(arrayOf("application/octet-stream", "*/*"))
        }
    }

    override fun onDestroy() {
        if (isFinishing) {
            worker.shutdownNow()
        }
        super.onDestroy()
    }

    private fun runCryptoOperation(
        runningMessage: String,
        successPrefix: String,
        operation: () -> Long
    ) {
        setBusy(true, runningMessage)

        worker.execute {
            val result = runCatching(operation)

            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread

                result.fold(
                    onSuccess = { byteCount ->
                        val message = "$successPrefix (${formatBytes(byteCount)})."
                        setBusy(false, message)
                        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                    },
                    onFailure = { error ->
                        val message = friendlyError(error)
                        setBusy(false, message)
                        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                    }
                )
            }
        }
    }

    private fun setBusy(busy: Boolean, status: String) {
        buttonEncrypt.isEnabled = !busy
        buttonDecrypt.isEnabled = !busy
        progressBar.visibility = if (busy) View.VISIBLE else View.GONE
        textStatus.text = status
    }

    private fun friendlyError(error: Throwable): String {
        val causes = generateSequence(error) { it.cause }.toList()
        val classNames = causes.joinToString(" ") { it::class.java.simpleName }
        val messages = causes.mapNotNull { it.message }.joinToString(" ")

        return when {
            causes.any { it is CoffreDocLegacyFormatException } ->
                "Ce fichier vient de CoffreDoc V1 (EncryptedFile). Le format V2 natif n'est pas compatible avec les anciens fichiers."

            causes.any { it is CoffreDocFormatException } ->
                "Fichier CoffreDoc invalide : ${causes.firstNotNullOfOrNull { it.message } ?: "format incorrect"}."

            causes.any { it is AEADBadTagException } ||
                "AEADBadTagException" in classNames ||
                "tag mismatch" in messages.lowercase() ||
                "mac check" in messages.lowercase() ->
                "Échec : fichier altéré ou clé différente. Vérifie qu'il a été chiffré par cette installation de CoffreDoc."

            causes.any { it is KeyStoreException } ||
                causes.any { it is GeneralSecurityException } ->
                "Échec cryptographique : la clé Android Keystore est absente, invalide ou inaccessible."

            causes.any { it is SecurityException } ->
                "Échec : Android a refusé l'accès au document."

            causes.any { it is IOException } ->
                "Échec d'entrée/sortie : ${causes.firstNotNullOfOrNull { it.message } ?: "document inaccessible"}."

            else ->
                "Échec du traitement : ${error.message ?: error::class.java.simpleName}."
        }
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes < 1024) return "$bytes octets"

        val units = arrayOf("Ko", "Mo", "Go", "To")
        var value = bytes.toDouble()
        var unitIndex = -1
        while (value >= 1024 && unitIndex < units.lastIndex) {
            value /= 1024
            unitIndex++
        }

        return "${DecimalFormat("0.##").format(value)} ${units[unitIndex]}"
    }
}
