# Format de conteneur NicoVault

L'extension reste `.ncrypt` et le magic reste `CDOC` pour la compatibilité.

## Versions

- version 1 : ancien conteneur `EncryptedFile`, non pris en charge ;
- version 2 : AES-256-GCM natif avec l'ancien alias Keystore ;
- version 3 : AES-256-GCM natif avec une clé Keystore exigeant une authentification récente.

Les versions 2 et 3 utilisent la même structure de blocs. La version permet à l'application de
sélectionner la bonne clé locale. Tous les nouveaux fichiers sont produits en version 3.

## En-tête global

- magic `CDOC` ;
- version sur 1 octet ;
- identifiant d'algorithme sur 1 octet ;
- taille de bloc déclarée sur 4 octets big-endian.

## Enregistrements

Chaque bloc contient :

- type ;
- index ;
- longueur claire ;
- IV aléatoire de 96 bits ;
- texte chiffré ;
- tag GCM de 128 bits.

L'en-tête global et l'en-tête de chaque bloc sont ajoutés aux données authentifiées. Un bloc final
vide et authentifié permet de détecter les troncatures sur une frontière de bloc.
