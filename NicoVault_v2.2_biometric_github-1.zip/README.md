# NicoVault 2.2

Petit coffre Android local pour chiffrer et déchiffrer des documents sur le téléphone.

## Sécurité

- écran verrouillé dès l'ouverture de l'application ;
- authentification avec biométrie forte ou verrouillage sécurisé de l'appareil ;
- reverrouillage lorsque l'application passe en arrière-plan ;
- captures d'écran et aperçu dans les applications récentes bloqués avec `FLAG_SECURE` ;
- clé AES-256 non exportable conservée dans Android Keystore ;
- la clé V3 exige une authentification récente pour être utilisée ;
- chiffrement `AES/GCM/NoPadding` par blocs authentifiés de 1 Mio ;
- aucune permission Internet ;
- aucune permission globale de stockage.

La clé utilise une fenêtre d'autorisation de cinq minutes afin qu'un document composé
de nombreux blocs puisse être traité sans redemander une empreinte à chaque bloc. L'interface
se reverrouille lorsqu'elle quitte le premier plan et redemande l'authentification au retour.

## Formats

- **V3** : format actuel, lié à la clé Keystore protégée par authentification ;
- **V2** : les fichiers créés par l'ancienne version native restent lisibles si l'ancienne
  clé `coffredoc_aes256_gcm_v2` existe encore dans cette même installation ;
- **V1 EncryptedFile** : non compatible.

Les nouveaux fichiers utilisent toujours la V3. Les anciens fichiers V2 importants doivent
être déchiffrés puis rechiffrés avec NicoVault 2.2 pour bénéficier de la protection de clé.

## Limite essentielle

La clé appartient à cette installation de l'application. Les fichiers deviennent illisibles après :

- désinstallation de l'application ;
- effacement de ses données ;
- changement de téléphone ;
- perte ou réinitialisation du Keystore Android.

## Compilation GitHub Actions

Le workflow `.github/workflows/build-apk.yml` exécute :

```bash
./gradlew --no-daemon --stacktrace clean testDebugUnitTest assembleDebug
```

L'artefact produit est :

```text
NicoVault-v2.2-debug-apk
```

Il contient l'APK et son empreinte SHA-256.

## Avertissement sur la signature des APK debug

Les runners GitHub peuvent recréer une clé de signature debug différente. Pour conserver les
données Keystore et installer les futures versions comme mises à jour, utilise à terme une clé
de signature stable. Ne désinstalle jamais l'application tant que des fichiers importants n'ont
pas été restaurés ailleurs.
